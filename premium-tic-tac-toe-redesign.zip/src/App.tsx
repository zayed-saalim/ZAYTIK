import { AnimatePresence, motion } from "framer-motion";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";

type Player = "X" | "O";
type CellValue = Player | null;
type GameMode = "duel" | "ai";

type ScoreBoard = {
  x: number;
  o: number;
  draw: number;
};

type BoardResult = {
  winner: Player | null;
  line: number[];
  draw: boolean;
};

const WINNING_LINES = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
] as const;

const CELL_LABELS = [
  "top left",
  "top center",
  "top right",
  "middle left",
  "center",
  "middle right",
  "bottom left",
  "bottom center",
  "bottom right",
];

const LINE_POINTS: Record<string, { x1: number; y1: number; x2: number; y2: number }> = {
  "0-1-2": { x1: 38, y1: 50, x2: 262, y2: 50 },
  "3-4-5": { x1: 38, y1: 150, x2: 262, y2: 150 },
  "6-7-8": { x1: 38, y1: 250, x2: 262, y2: 250 },
  "0-3-6": { x1: 50, y1: 38, x2: 50, y2: 262 },
  "1-4-7": { x1: 150, y1: 38, x2: 150, y2: 262 },
  "2-5-8": { x1: 250, y1: 38, x2: 250, y2: 262 },
  "0-4-8": { x1: 45, y1: 45, x2: 255, y2: 255 },
  "2-4-6": { x1: 255, y1: 45, x2: 45, y2: 255 },
};

const emptyBoard = (): CellValue[] => Array<CellValue>(9).fill(null);

function getOtherPlayer(player: Player): Player {
  return player === "X" ? "O" : "X";
}

function evaluateBoard(board: CellValue[]): BoardResult {
  for (const line of WINNING_LINES) {
    const [a, b, c] = line;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      return { winner: board[a], line: [...line], draw: false };
    }
  }

  return {
    winner: null,
    line: [],
    draw: board.every((cell) => cell !== null),
  };
}

function getOpenCells(board: CellValue[]) {
  return board.reduce<number[]>((openCells, cell, index) => {
    if (cell === null) openCells.push(index);
    return openCells;
  }, []);
}

function minimax(
  board: CellValue[],
  isMaximizing: boolean,
  ai: Player,
  human: Player,
  depth: number,
  alpha: number,
  beta: number,
): number {
  const result = evaluateBoard(board);

  if (result.winner === ai) return 10 - depth;
  if (result.winner === human) return depth - 10;
  if (result.draw) return 0;

  if (isMaximizing) {
    let bestScore = Number.NEGATIVE_INFINITY;

    for (const move of getOpenCells(board)) {
      board[move] = ai;
      const score = minimax(board, false, ai, human, depth + 1, alpha, beta);
      board[move] = null;
      bestScore = Math.max(bestScore, score);
      alpha = Math.max(alpha, score);
      if (beta <= alpha) break;
    }

    return bestScore;
  }

  let bestScore = Number.POSITIVE_INFINITY;

  for (const move of getOpenCells(board)) {
    board[move] = human;
    const score = minimax(board, true, ai, human, depth + 1, alpha, beta);
    board[move] = null;
    bestScore = Math.min(bestScore, score);
    beta = Math.min(beta, score);
    if (beta <= alpha) break;
  }

  return bestScore;
}

function getBestMove(board: CellValue[], ai: Player = "O", human: Player = "X") {
  if (evaluateBoard(board).winner || evaluateBoard(board).draw) return -1;

  let bestScore = Number.NEGATIVE_INFINITY;
  let bestMove = getOpenCells(board)[0] ?? -1;
  const boardCopy = [...board];

  for (const move of getOpenCells(boardCopy)) {
    boardCopy[move] = ai;
    const score = minimax(
      boardCopy,
      false,
      ai,
      human,
      0,
      Number.NEGATIVE_INFINITY,
      Number.POSITIVE_INFINITY,
    );
    boardCopy[move] = null;

    if (score > bestScore) {
      bestScore = score;
      bestMove = move;
    }
  }

  return bestMove;
}

function App() {
  const [board, setBoard] = useState<CellValue[]>(() => emptyBoard());
  const [currentPlayer, setCurrentPlayer] = useState<Player>("X");
  const [scores, setScores] = useState<ScoreBoard>({ x: 0, o: 0, draw: 0 });
  const [mode, setMode] = useState<GameMode>("duel");
  const [lastMove, setLastMove] = useState<number | null>(null);
  const [roundId, setRoundId] = useState(1);
  const [showHelp, setShowHelp] = useState(false);

  const cellRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const closeHelpRef = useRef<HTMLButtonElement | null>(null);
  const scoredRoundRef = useRef<number | null>(null);

  const result = useMemo(() => evaluateBoard(board), [board]);
  const resultComplete = Boolean(result.winner) || result.draw;
  const aiThinking = mode === "ai" && currentPlayer === "O" && !resultComplete;
  const winningLine = result.line.length ? LINE_POINTS[result.line.join("-")] : null;
  const totalRounds = scores.x + scores.o + scores.draw;

  const statusText = useMemo(() => {
    if (result.winner) return `Player ${result.winner} wins the round.`;
    if (result.draw) return "Stalemate. No spaces left on the board.";
    if (aiThinking) return "ZAY AI is calculating the cleanest move.";
    if (mode === "ai") return "Your move. Place X before the AI responds.";
    return `Player ${currentPlayer}'s turn.`;
  }, [aiThinking, currentPlayer, mode, result.draw, result.winner]);

  const restartRound = useCallback(() => {
    setBoard(emptyBoard());
    setCurrentPlayer("X");
    setLastMove(null);
    setRoundId((id) => id + 1);
  }, []);

  const resetMatch = useCallback(() => {
    setScores({ x: 0, o: 0, draw: 0 });
    restartRound();
  }, [restartRound]);

  const makeMove = useCallback(
    (index: number, player: Player = currentPlayer) => {
      const currentResult = evaluateBoard(board);
      const blockedByAi = mode === "ai" && currentPlayer === "O" && player === "X";

      if (board[index] || currentResult.winner || currentResult.draw || blockedByAi) return;
      if (player !== currentPlayer) return;

      const nextBoard = [...board];
      nextBoard[index] = player;
      const nextResult = evaluateBoard(nextBoard);

      setBoard(nextBoard);
      setLastMove(index);

      if (!nextResult.winner && !nextResult.draw) {
        setCurrentPlayer(getOtherPlayer(player));
      }
    },
    [board, currentPlayer, mode],
  );

  const focusBoard = useCallback(() => {
    const firstOpenCell = board.findIndex((cell) => cell === null);
    cellRefs.current[firstOpenCell === -1 ? 0 : firstOpenCell]?.focus();
  }, [board]);

  const selectMode = useCallback(
    (nextMode: GameMode) => {
      if (mode === nextMode) return;
      setMode(nextMode);
      restartRound();
    },
    [mode, restartRound],
  );

  const handleCellKeyDown = (event: React.KeyboardEvent<HTMLButtonElement>, index: number) => {
    const keyToNextIndex: Record<string, number> = {
      ArrowRight: (index + 1) % 9,
      ArrowLeft: (index + 8) % 9,
      ArrowDown: (index + 3) % 9,
      ArrowUp: (index + 6) % 9,
      Home: 0,
      End: 8,
    };

    const nextIndex = keyToNextIndex[event.key];
    if (nextIndex === undefined) return;

    event.preventDefault();
    cellRefs.current[nextIndex]?.focus();
  };

  useEffect(() => {
    if (!result.winner && !result.draw) return;
    if (scoredRoundRef.current === roundId) return;

    scoredRoundRef.current = roundId;

    setScores((currentScores) => {
      if (result.winner === "X") return { ...currentScores, x: currentScores.x + 1 };
      if (result.winner === "O") return { ...currentScores, o: currentScores.o + 1 };
      return { ...currentScores, draw: currentScores.draw + 1 };
    });
  }, [result.draw, result.winner, roundId]);

  useEffect(() => {
    if (!aiThinking) return;

    const timer = window.setTimeout(() => {
      const move = getBestMove(board);
      if (move !== -1) makeMove(move, "O");
    }, 520);

    return () => window.clearTimeout(timer);
  }, [aiThinking, board, makeMove]);

  useEffect(() => {
    if (!showHelp) return;

    closeHelpRef.current?.focus();

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setShowHelp(false);
    };

    window.addEventListener("keydown", handleEscape);
    return () => window.removeEventListener("keydown", handleEscape);
  }, [showHelp]);

  const playerGradient =
    currentPlayer === "X"
      ? "from-cyan-200 via-sky-300 to-blue-500"
      : "from-fuchsia-200 via-pink-300 to-rose-500";

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#040713] text-white">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_15%,rgba(34,211,238,0.25),transparent_32%),radial-gradient(circle_at_88%_18%,rgba(217,70,239,0.20),transparent_30%),radial-gradient(circle_at_48%_92%,rgba(99,102,241,0.22),transparent_36%)]" />
      <motion.div
        aria-hidden="true"
        className="absolute left-[-20%] top-[-18rem] h-[42rem] w-[70rem] rotate-[-12deg] rounded-full bg-cyan-300/20 blur-3xl"
        animate={{ x: ["-6%", "12%", "-6%"], opacity: [0.2, 0.42, 0.2] }}
        transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        aria-hidden="true"
        className="absolute bottom-[-24rem] right-[-18rem] h-[46rem] w-[46rem] rounded-full bg-fuchsia-500/20 blur-3xl"
        animate={{ scale: [1, 1.18, 1], opacity: [0.18, 0.36, 0.18] }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      <div aria-hidden="true" className="luxury-grid absolute inset-0 opacity-45" />

      <div className="relative mx-auto flex min-h-screen w-full max-w-7xl flex-col px-5 py-5 sm:px-8 lg:px-10">
        <header className="flex items-center justify-between gap-5 border-b border-white/10 pb-5">
          <button
            type="button"
            onClick={focusBoard}
            className="group inline-flex items-center gap-3 text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200 focus-visible:ring-offset-4 focus-visible:ring-offset-[#040713]"
            aria-label="Focus the ZAY TIK game board"
          >
            <span className="grid h-11 w-11 place-items-center rounded-2xl border border-white/15 bg-white/[0.06] text-lg font-black tracking-tight text-cyan-100 transition group-hover:border-cyan-200/60 group-hover:bg-cyan-200/10">
              Z
            </span>
            <span>
              <span className="block text-sm font-semibold uppercase tracking-[0.35em] text-white/45">
                ZAY TIK
              </span>
              <span className="block text-sm text-white/55">Premium tic tac toe arena</span>
            </span>
          </button>

          <button
            type="button"
            onClick={() => setShowHelp(true)}
            className="rounded-full border border-white/15 px-4 py-2 text-sm font-semibold text-white/75 transition hover:border-cyan-200/70 hover:bg-cyan-200/10 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200 focus-visible:ring-offset-4 focus-visible:ring-offset-[#040713]"
          >
            How to play
          </button>
        </header>

        <section className="grid flex-1 items-center gap-10 py-10 lg:grid-cols-[0.92fr_1.08fr] lg:gap-14 lg:py-14">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: "easeOut" }}
            className="max-w-2xl"
          >
            <p className="mb-5 text-sm font-semibold uppercase tracking-[0.38em] text-cyan-100/70">
              Classic rules. Executive polish.
            </p>
            <h1 className="text-balance text-6xl font-black tracking-[-0.08em] text-white sm:text-7xl lg:text-8xl">
              ZAY TIK
              <span className="mt-4 block max-w-xl text-3xl font-semibold tracking-[-0.04em] text-white/72 sm:text-4xl lg:text-5xl">
                Tic tac toe redesigned as a cinematic match room.
              </span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-white/62">
              Play local duels or challenge a perfect minimax AI. Every move is keyboard accessible,
              screen-reader announced, and wrapped in sharp motion feedback.
            </p>

            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <button
                type="button"
                onClick={resultComplete ? restartRound : focusBoard}
                className="rounded-full bg-white px-6 py-3 text-sm font-bold uppercase tracking-[0.18em] text-[#06101f] transition hover:-translate-y-0.5 hover:bg-cyan-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-4 focus-visible:ring-offset-[#040713]"
              >
                {resultComplete ? "Next round" : "Play now"}
              </button>
              <button
                type="button"
                onClick={resetMatch}
                className="rounded-full border border-white/15 px-6 py-3 text-sm font-bold uppercase tracking-[0.18em] text-white/72 transition hover:-translate-y-0.5 hover:border-fuchsia-200/60 hover:bg-fuchsia-200/10 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-fuchsia-200 focus-visible:ring-offset-4 focus-visible:ring-offset-[#040713]"
              >
                Reset match
              </button>
            </div>
          </motion.div>

          <motion.section
            initial={{ opacity: 0, y: 28, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ duration: 0.75, delay: 0.1, ease: "easeOut" }}
            className="relative"
            aria-label="ZAY TIK game"
          >
            <div className="absolute -inset-4 rounded-[2.75rem] bg-cyan-300/10 blur-2xl sm:-inset-8" />
            <div className="relative overflow-hidden rounded-[2rem] border border-white/12 bg-[#07101f]/78 p-5 shadow-[0_30px_120px_rgba(0,0,0,0.45)] backdrop-blur-2xl sm:p-7">
              <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cyan-200/70 to-transparent" />

              <div className="flex flex-col gap-5 border-b border-white/10 pb-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.28em] text-white/38">Live status</p>
                  <AnimatePresence mode="wait">
                    <motion.p
                      key={statusText}
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      transition={{ duration: 0.22 }}
                      className="mt-2 text-lg font-semibold text-white"
                      role="status"
                      aria-live="polite"
                    >
                      {statusText}
                    </motion.p>
                  </AnimatePresence>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold uppercase tracking-[0.24em] text-white/38">Turn</span>
                  <motion.span
                    key={currentPlayer}
                    initial={{ opacity: 0, rotateX: -70 }}
                    animate={{ opacity: 1, rotateX: 0 }}
                    className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${playerGradient} text-2xl font-black text-[#06101f] shadow-lg shadow-cyan-950/40`}
                  >
                    {currentPlayer}
                  </motion.span>
                </div>
              </div>

              <div className="mt-5 flex flex-wrap items-center justify-between gap-4">
                <div className="inline-flex rounded-full border border-white/10 bg-white/[0.04] p-1" aria-label="Game mode">
                  {([
                    { id: "duel", label: "Duel" },
                    { id: "ai", label: "ZAY AI" },
                  ] as const).map((option) => (
                    <button
                      key={option.id}
                      type="button"
                      onClick={() => selectMode(option.id)}
                      className={`rounded-full px-4 py-2 text-sm font-bold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200 focus-visible:ring-offset-2 focus-visible:ring-offset-[#07101f] ${
                        mode === option.id
                          ? "bg-white text-[#06101f]"
                          : "text-white/55 hover:bg-white/[0.07] hover:text-white"
                      }`}
                      aria-pressed={mode === option.id}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>

                <p className="text-sm font-medium text-white/45">
                  {totalRounds === 0 ? "First round" : `${totalRounds} scored round${totalRounds === 1 ? "" : "s"}`}
                </p>
              </div>

              <div className="relative mx-auto mt-6 aspect-square w-full max-w-[32rem]">
                <div
                  className="grid h-full w-full grid-cols-3 gap-3 rounded-[1.6rem] bg-white/10 p-3"
                  role="grid"
                  aria-label="Tic tac toe game board"
                >
                  {board.map((cell, index) => {
                    const isWinningCell = result.line.includes(index);
                    const canSelect = !cell && !resultComplete && !aiThinking;
                    const cellTone = cell === "X" ? "text-cyan-100" : "text-fuchsia-100";
                    const markedTone =
                      cell === "X"
                        ? "border-cyan-200/35 bg-cyan-200/[0.08]"
                        : cell === "O"
                          ? "border-fuchsia-200/35 bg-fuchsia-200/[0.08]"
                          : "border-white/10 bg-[#07101f]/92 hover:border-white/25 hover:bg-white/[0.08]";
                    const winningTone = isWinningCell
                      ? cell === "X"
                        ? "border-cyan-100/80 bg-cyan-200/20 shadow-[0_0_34px_rgba(103,232,249,0.22)]"
                        : "border-fuchsia-100/80 bg-fuchsia-200/20 shadow-[0_0_34px_rgba(240,171,252,0.2)]"
                      : "";

                    return (
                      <motion.button
                        key={`${roundId}-${index}`}
                        ref={(node) => {
                          cellRefs.current[index] = node;
                        }}
                        type="button"
                        role="gridcell"
                        aria-label={
                          cell
                            ? `${CELL_LABELS[index]} cell marked ${cell}`
                            : `${CELL_LABELS[index]} cell empty. Player ${currentPlayer} can place here.`
                        }
                        aria-disabled={!canSelect}
                        onClick={() => makeMove(index)}
                        onKeyDown={(event) => handleCellKeyDown(event, index)}
                        whileHover={canSelect ? { y: -4, scale: 1.015 } : undefined}
                        whileTap={canSelect ? { scale: 0.96 } : undefined}
                        animate={{ scale: isWinningCell ? [1, 1.045, 1] : 1 }}
                        transition={
                          isWinningCell
                            ? { duration: 1.25, repeat: Infinity, ease: "easeInOut" }
                            : { type: "spring", stiffness: 300, damping: 24 }
                        }
                        className={`group relative overflow-hidden rounded-[1.15rem] border text-6xl font-black tracking-[-0.08em] transition focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200 focus-visible:ring-offset-4 focus-visible:ring-offset-[#07101f] sm:text-7xl ${
                          canSelect ? "cursor-pointer" : "cursor-default"
                        } ${markedTone} ${winningTone}`}
                      >
                        {lastMove === index && (
                          <motion.span
                            aria-hidden="true"
                            className="absolute inset-3 rounded-[0.85rem] border border-white/20"
                            initial={{ opacity: 0.8, scale: 0.65 }}
                            animate={{ opacity: 0, scale: 1.18 }}
                            transition={{ duration: 0.6, ease: "easeOut" }}
                          />
                        )}

                        <AnimatePresence mode="wait">
                          {cell ? (
                            <motion.span
                              key={cell}
                              initial={{ opacity: 0, scale: 0.45, rotate: -12 }}
                              animate={{ opacity: 1, scale: 1, rotate: 0 }}
                              exit={{ opacity: 0, scale: 0.45 }}
                              transition={{ type: "spring", stiffness: 420, damping: 22 }}
                              className={`relative z-10 ${cellTone}`}
                            >
                              {cell}
                            </motion.span>
                          ) : (
                            <span className="relative z-10 text-base font-bold tracking-normal text-white/16 transition group-hover:text-white/30">
                              {index + 1}
                            </span>
                          )}
                        </AnimatePresence>
                      </motion.button>
                    );
                  })}
                </div>

                <AnimatePresence>
                  {winningLine && (
                    <motion.svg
                      key={result.line.join("-")}
                      className="pointer-events-none absolute inset-0 h-full w-full overflow-visible"
                      viewBox="0 0 300 300"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      aria-hidden="true"
                    >
                      <motion.line
                        x1={winningLine.x1}
                        y1={winningLine.y1}
                        x2={winningLine.x2}
                        y2={winningLine.y2}
                        stroke="url(#winStroke)"
                        strokeWidth="10"
                        strokeLinecap="round"
                        initial={{ pathLength: 0 }}
                        animate={{ pathLength: 1 }}
                        transition={{ duration: 0.52, ease: "easeOut" }}
                      />
                      <defs>
                        <linearGradient id="winStroke" x1="0" x2="1" y1="0" y2="1">
                          <stop stopColor="#67e8f9" />
                          <stop offset="1" stopColor="#f0abfc" />
                        </linearGradient>
                      </defs>
                    </motion.svg>
                  )}
                </AnimatePresence>
              </div>

              <div className="mt-6 grid grid-cols-3 divide-x divide-white/10 border-y border-white/10 py-4" aria-label="Score board">
                {[
                  { label: "X Wins", value: scores.x, tone: "text-cyan-100" },
                  { label: "Draws", value: scores.draw, tone: "text-white" },
                  { label: "O Wins", value: scores.o, tone: "text-fuchsia-100" },
                ].map((score) => (
                  <div key={score.label} className="px-3 text-center">
                    <p className="text-[0.68rem] font-bold uppercase tracking-[0.26em] text-white/34">{score.label}</p>
                    <p className={`mt-2 text-3xl font-black ${score.tone}`}>{score.value}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex flex-col gap-3 sm:flex-row">
                <button
                  type="button"
                  onClick={restartRound}
                  className="flex-1 rounded-2xl border border-white/15 px-5 py-3 text-sm font-bold uppercase tracking-[0.18em] text-white/75 transition hover:border-cyan-200/60 hover:bg-cyan-200/10 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200 focus-visible:ring-offset-4 focus-visible:ring-offset-[#07101f]"
                >
                  Restart round
                </button>
                <button
                  type="button"
                  onClick={resetMatch}
                  className="flex-1 rounded-2xl bg-white px-5 py-3 text-sm font-bold uppercase tracking-[0.18em] text-[#06101f] transition hover:bg-cyan-100 focus:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-4 focus-visible:ring-offset-[#07101f]"
                >
                  New game
                </button>
              </div>
            </div>
          </motion.section>
        </section>

        <footer className="flex flex-col gap-2 border-t border-white/10 py-5 text-sm text-white/42 sm:flex-row sm:items-center sm:justify-between">
          <p>ZAY TIK is optimized for touch, mouse, keyboard, and screen readers.</p>
          <p>Arrow keys move across the board. Enter or Space places a mark.</p>
        </footer>
      </div>

      <AnimatePresence>
        {showHelp && (
          <motion.div
            className="fixed inset-0 z-50 grid place-items-center bg-[#02040c]/80 p-5 backdrop-blur-xl"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            role="dialog"
            aria-modal="true"
            aria-labelledby="help-title"
          >
            <motion.div
              initial={{ opacity: 0, y: 26, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.96 }}
              transition={{ duration: 0.24, ease: "easeOut" }}
              className="relative w-full max-w-xl rounded-[2rem] border border-white/12 bg-[#081020] p-6 shadow-[0_40px_140px_rgba(0,0,0,0.55)] sm:p-8"
            >
              <button
                ref={closeHelpRef}
                type="button"
                onClick={() => setShowHelp(false)}
                className="absolute right-4 top-4 rounded-full border border-white/10 px-3 py-2 text-sm font-bold text-white/60 transition hover:border-white/30 hover:text-white focus:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200 focus-visible:ring-offset-4 focus-visible:ring-offset-[#081020]"
              >
                Close
              </button>

              <p className="text-sm font-semibold uppercase tracking-[0.32em] text-cyan-100/60">Rules</p>
              <h2 id="help-title" className="mt-3 text-3xl font-black tracking-[-0.05em] text-white">
                How to play ZAY TIK
              </h2>
              <ol className="mt-6 space-y-4 text-base leading-7 text-white/68">
                <li>1. X always opens the round.</li>
                <li>2. Players alternate by choosing any empty square.</li>
                <li>3. Three matching marks in a row, column, or diagonal wins.</li>
                <li>4. If all nine cells fill with no winner, the round is scored as a draw.</li>
                <li>5. In ZAY AI mode, you play X against a perfect minimax opponent.</li>
                <li>6. Use Tab or arrow keys to move, then Enter or Space to place a mark.</li>
              </ol>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}

export default App;